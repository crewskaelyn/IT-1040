def student_data(filename: str):
    students = []

    with open(filename, 'r') as f:
        for line in f:
            data = line.strip("\n").split(",")
            
            students.append(data)

    return students

def calculate_grade(score):
    grade = ""

    if score > 90 and score <= 100:
        grade = "A"
    elif score > 80 and score <= 90:
        grade = "B"
    elif score > 70 and score <= 80:
        grade = "C"
    elif score > 60 and score <= 70:
        grade = "D"
    else:
        grade = "F"

    return grade

def calculate_statistics(students: list):
    total_score = 0
    high_score = float(students[0][2])
    low_score = float(students[0][2])

    for student in students:
        score = float(student[2])

        total_score += score

        if score > high_score:
            high_score = score

        if score < low_score:
            low_score = score

    average_letter_grade = calculate_grade(total_score / len(students))
    average_grade = round((total_score / len(students)), 2)
    no_of_students = len(students)
    Range = round((high_score - low_score),2)

    print("\nClass Statistics:")
    print(f"Class Average: {average_grade} -> {average_letter_grade}")
    print(f"Number of Students: {no_of_students}")
    print(f"High Score: {high_score}")
    print(f"Low Score: {low_score}")
    print(f"Range of Scores: {Range}")

  
def main():
    input_file = "student_data.txt"
    output_file = "student_output.txt"

    students = student_data(input_file)

    for index in range(len(students)):
        first_name = students[index][0]
        last_name = students[index][1]
        grade = students[index][2]
        letter_grade = calculate_grade(float(students[index][2]))
        students[index].append(letter_grade)

        print(f"{first_name} {last_name} : {grade} -> {letter_grade}")


    with open(output_file, 'w') as f:
        for student in students:
            f.write(",".join(student) + "\n")

    calculate_statistics(students)

main()











    
    
