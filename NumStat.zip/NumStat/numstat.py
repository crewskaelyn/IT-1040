def stats():
    try:
        fname = input("Please enter the name of the file to be opened: ")
        file = open(fname, 'r')

        nums = file.readlines()
        nums = [int(i) for i in nums]

        print("File name: ", fname)
        print("Sum: ", sum(nums))
        print("Count: ", len(nums))
        print("Average: ", (sum(nums) / len(nums)))
        print("Maximum: ", (max(nums)))
        print("Minimum: ", min(nums))
        print("Range: ", (max(nums)) - (min(nums)))
              
    except Exception as err:
        print(err)

def main():
    while True:
        stats()
        another = input("Would you like to open another file? (y/n) ")
        if another == 'y':
            continue
        else:
            break
       
main()
