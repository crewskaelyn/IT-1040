def main():
    print('List of random numbers in randomnum.txt:')
    try:
        file = open("C:/Users/docto/OneDrive/Desktop/Python Projects/RandomWriteRead/randomnum.txt")
        print(file.read())
    except Exception as err:
        print(err)
    finally:
        file.close()



main()
