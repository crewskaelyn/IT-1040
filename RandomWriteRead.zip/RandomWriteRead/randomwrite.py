import random

def non_negative(prompt):
    while True:
        try:
            input_value = int(input(prompt))
            if (input_value < 0):
                print("Please enter a positive value")
                continue
            break
        except ValueError:
            print('Please enter a positive numerical value')
            continue
    return input_value

def main():
    
    quantity = non_negative('How many random numbers do you want to generate?')
    low = non_negative('What is the lowest the random number should be?')
    high = non_negative('What is the highest the random number should be?')


    try:
        file = open("randomnum.txt", "w")
        for number in range(quantity):
            random_number = random.randint(low, high)
            random_number = str(random_number)
            file.write(random_number)
            file.write('\n')
    except Exception as err:
        print(err)
    else:
        print('The random numbers were written to randomnum.txt')
    finally:
        file.close()
    
main()
