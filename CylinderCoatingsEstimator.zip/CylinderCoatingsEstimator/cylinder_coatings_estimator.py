import math

def user_input(prompt):
    while True:
        try:
            input_value = float(input(prompt))
            if (input_value < 0):
                print("Please enter a positive value")
                continue
            break
        except ValueError:
            print('Please enter a positive numerical value')
            continue
    return input_value

def calculation():
    radius = user_input("What is the cylinder's radius?")
    height = user_input("What is the cylinder's height?")
    cost_per_pint = user_input("What is the cost per pint of coating?")

    surface_area = 2 * math.pi * radius * height + 2 * math.pi * radius ** 2
    pints = (math.ceil(surface_area / 50))
    cost = pints * cost_per_pint
    
    print('The amount of pints needed is ', pints)
    print('The estimated cost is $', '{:0.2f}'.format(cost))

def main():
    print('This program calculates the price of coating a cylinder.')
    while True:
        calculation()
        another_calc = input('Would you like to perform another calculation? (y/n)')
        if (another_calc == 'y'):
            continue
        else:
            break

main()
