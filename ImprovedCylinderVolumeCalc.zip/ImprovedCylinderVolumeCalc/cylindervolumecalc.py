do_calulation = True
while (do_calulation):
    
        while True:
            try:
                radius = float(input("Radius of the cylinder:"))
                if radius < 0:
                    raise ValueError
                break
            except ValueError:
                print('Please enter a positive numerical value.')

        while True:
            try:
                height = float(input("Height of the cylinder:"))
                if height < 0:
                     raise ValueError
                break
            except ValueError:
                print('Please enter a positive numerical value.')

        volume = 3.14159 * height * radius * radius

        print("The volume of the cylinder is ", volume)

        another_calulation = input("Would you like to perfofm another calculation? (y/n)")
        if (another_calulation != "y"):
            do_calculation = False
            break



