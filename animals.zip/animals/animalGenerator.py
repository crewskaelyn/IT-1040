from animals import Animal

def main():

    print("Welcome to the animal generator!")
    print("This program creates Animal objects.")

    list_of_animals = []

    while True:
        animal_type = input("\nWhat type of animal would you like to create? ")
        name = input("What is the animal's name? ")

        animal = Animal(animal_type,name)
        list_of_animals.append(animal)

        repeat = input("\nWould you like to add another animal? (y/n) ")
        if repeat != 'y':
            break
        
    print('\nAnimal List:')
    for animal in list_of_animals:
        print(animal.get_name(), " the ", animal.get_animal_type(), " is ", animal.check_mood())

main()            

