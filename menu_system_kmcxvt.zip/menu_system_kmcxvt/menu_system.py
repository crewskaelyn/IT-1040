import math
choice = ''
order_log_data = []

def get_files(filename: str):
    data = []
    with open(filename, 'r') as file:
        for line in file:
            lines = line.strip('\n').split(', ')
            if (len(lines) == 2):
                lines[1] = lines[1][0:]
                data.append(lines)
            if (len(lines) == 4):
                lines[1] = lines[1][0:]
                lines[2] = lines[2][0:]
                lines[3] = lines[3][0:]
                data.append(lines)
    return data
           
def admin():
    credentials = get_files('credentials.txt')
    
    print("\nAdmin Login\n-------------")
    run = 0
    while (run == 0):
        username = input("Enter Username: ")
        password = input("Enter Password: ")
        if(username == credentials[0][0] and password == credentials[0][1]) or  (username == credentials[1][0] and password == credentials[1][1])  or  (username == credentials[2][0] and password == credentials[2][1]):
            order_log = get_files('order_log.txt')
            
            menu_total = 0
            
            for i in order_log:
                item_total = round(float(i[2]) * int(i[3]), 2)
                print(f'{i[1]} : {i[3]} units sold @ ${i[2]} = {item_total}')
                menu_total += item_total
            print(f'\nTotal: {round(menu_total,2)}')
                
            print("You are logged out now!")
            run = 1
            break
        else:
            print("Invalid username and password combination!")
            continue

        

def new_data(number:int, item:str, ammount:int, price:float):
    return[number, item, ammount, price]

def order():
    keep_ordering = 'YES'
    total = 0.0
    ammount = 0.0
    
    while keep_ordering == 'YES':
        print("\nChoose an option from the menu below\n-------------------------------------")
        print("1. Pizza.............$10.99\n2. Hamburger.........$5.49\n3. Hotdog............$3.79\n4. French Fries......$1.89\n5. Onion Rings.......$2.19\n6. Soda..............$1.19\n7. Water.............$0.79")
        order_choice = input("\nChoose option: ")
        ammount = int(input("How many would you like? "))
        if order_choice == '1':
            print(f"You selected {ammount} Pizza(s)")
            total += (ammount * 10.99)
            order_log_data.append(new_data(1, 'Pizza', ammount, 10.99))
            
        elif order_choice == '2':
            print(f"You selected {ammount} Hamburger(s)")
            total += (ammount * 5.49)
            order_log_data.append(new_data(2, 'Hamburger', ammount, 5.49))
            
        elif order_choice == '3':
            print(f"You selected {ammount} Hotdog(s)")
            total += (ammount * 3.79)
            order_log_data.append(new_data(3, 'Hotdog', ammount, 3.79))
            
        elif order_choice == '4':
            print(f"You selected {ammount} French Fries")
            total += (ammount * 1.89)
            order_log_data.append(new_data(4, 'French Fries', ammount, 1.89))
        
        elif order_choice == '5':
            print(f"You selected {ammount} Onion Rings")
            total += (ammount * 2.19)
            order_log_data.append(new_data(5, 'Onion Rings', ammount, 2.19))
            
        elif order_choice == '6':
            print(f"You selected {ammount} Soda(s)")
            total += (ammount * 1.19)
            order_log_data.append(new_data(6, 'Soda', ammount, 1.19))
            
        elif order_choice == '7':
            print(f"You selected {ammount} Water(s)")
            total += (ammount * 0.79)
            order_log_data.append(new_data(7, 'Water', ammount, 0.79))
            
        else:
            print("Please choose an option from the menu above")
            
        keep_ordering = input("Would you like to keep ordering? Enter yes or no. ").upper()
        if keep_ordering == 'YES':
            continue
        elif keep_ordering == 'NO':
            print("Your order has been placed successfully!")
            print('Your total is: ', round(total, 2))
            updated_log = []
            order_log = get_files('order_log.txt')
            for i in order_log:
                orders = [int(i[0]), i[1], float(i[2]), int(i[3])]
                updated_log.append(orders)
            for i in updated_log:
                for j in order_log_data:
                    if i[1] == j[1]:
                        i[3] += j[2]

            with open('order_log.txt', 'w') as f:
                for i in updated_log:
                    f.write(f'{i[0]}, {i[1]}, {i[2]}, {i[3]}\n')
            break
        else:
            print('Invalid answer, enter yes or no.\n')
                

def main():
    run = True
    while(run):
        print("\nChoose an option from the menu below\n-------------------------------------")
        print("1. Administrator Login\n2. Place Order\n3. Logout\n")
        choice = input("Choose option: ")
        if choice == '1':
            admin()
            continue

        elif choice == '2':
            order()
            continue

        elif choice == '3':
            run = False
            print("Have a nice day! Goodbye :-)")
            break
        else:
            print('ERROR: You must enter a 1, 2, or 3\n')
        
        

main()




                     
    
