radius_string = input("Radius of the cylinder:")
height_string = input("Height of the cylinder:")

radius = float(radius_string)
height = float(height_string)

volume = 3.14159 * height * radius * radius

print("The volume of the cylinder is ", volume)
